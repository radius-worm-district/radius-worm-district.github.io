﻿namespace De_Gokkers
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.PlayerWedName = new System.Windows.Forms.Label();
            this.Wed_Button = new System.Windows.Forms.Button();
            this.Choose_Worm = new System.Windows.Forms.NumericUpDown();
            this.Inzet_Euro = new System.Windows.Forms.NumericUpDown();
            this.PlayerFedde = new System.Windows.Forms.RadioButton();
            this.PlayerFer = new System.Windows.Forms.RadioButton();
            this.PlayerSietse = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.WedLblWorm1 = new System.Windows.Forms.Label();
            this.WedLblWorm4 = new System.Windows.Forms.Label();
            this.WedLblWorm3 = new System.Windows.Forms.Label();
            this.WedLblWorm2 = new System.Windows.Forms.Label();
            this.WedLblWorm5 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.Start_Button = new System.Windows.Forms.Button();
            this.Worm = new System.Windows.Forms.PictureBox();
            this.WormTwo = new System.Windows.Forms.PictureBox();
            this.WormSpecial = new System.Windows.Forms.PictureBox();
            this.WormOne = new System.Windows.Forms.PictureBox();
            this.WormThree = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Choose_Worm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Inzet_Euro)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Worm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WormTwo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WormSpecial)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WormOne)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WormThree)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.PlayerWedName);
            this.panel1.Controls.Add(this.Wed_Button);
            this.panel1.Controls.Add(this.Choose_Worm);
            this.panel1.Controls.Add(this.Inzet_Euro);
            this.panel1.Controls.Add(this.PlayerFedde);
            this.panel1.Controls.Add(this.PlayerFer);
            this.panel1.Controls.Add(this.PlayerSietse);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 81);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(562, 174);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(372, 99);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(178, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Je kunt op een worm alleen wedden";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(372, 76);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(136, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Maximale bedrag is 15 euro";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(372, 53);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(127, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Minimum bedrag is 5 euro";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(234, 138);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Euro op worm";
            // 
            // PlayerWedName
            // 
            this.PlayerWedName.AutoSize = true;
            this.PlayerWedName.Location = new System.Drawing.Point(38, 136);
            this.PlayerWedName.MinimumSize = new System.Drawing.Size(150, 20);
            this.PlayerWedName.Name = "PlayerWedName";
            this.PlayerWedName.Size = new System.Drawing.Size(150, 20);
            this.PlayerWedName.TabIndex = 9;
            this.PlayerWedName.Text = "(Player) wed";
            this.PlayerWedName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Wed_Button
            // 
            this.Wed_Button.Location = new System.Drawing.Point(352, 133);
            this.Wed_Button.Name = "Wed_Button";
            this.Wed_Button.Size = new System.Drawing.Size(75, 23);
            this.Wed_Button.TabIndex = 8;
            this.Wed_Button.Text = "Wed";
            this.Wed_Button.UseVisualStyleBackColor = true;
            this.Wed_Button.Click += new System.EventHandler(this.Wed_Button_Click);
            // 
            // Choose_Worm
            // 
            this.Choose_Worm.Location = new System.Drawing.Point(312, 136);
            this.Choose_Worm.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.Choose_Worm.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.Choose_Worm.Name = "Choose_Worm";
            this.Choose_Worm.Size = new System.Drawing.Size(34, 20);
            this.Choose_Worm.TabIndex = 7;
            this.Choose_Worm.Tag = "0";
            this.Choose_Worm.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.Choose_Worm.ValueChanged += new System.EventHandler(this.Choose_Worm_ValueChanged);
            // 
            // Inzet_Euro
            // 
            this.Inzet_Euro.Location = new System.Drawing.Point(194, 136);
            this.Inzet_Euro.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.Inzet_Euro.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.Inzet_Euro.Name = "Inzet_Euro";
            this.Inzet_Euro.Size = new System.Drawing.Size(34, 20);
            this.Inzet_Euro.TabIndex = 6;
            this.Inzet_Euro.Tag = "4";
            this.Inzet_Euro.Value = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.Inzet_Euro.ValueChanged += new System.EventHandler(this.Inzet_Euro_ValueChanged);
            // 
            // PlayerFedde
            // 
            this.PlayerFedde.AutoSize = true;
            this.PlayerFedde.Checked = true;
            this.PlayerFedde.Location = new System.Drawing.Point(25, 97);
            this.PlayerFedde.Name = "PlayerFedde";
            this.PlayerFedde.Size = new System.Drawing.Size(55, 17);
            this.PlayerFedde.TabIndex = 5;
            this.PlayerFedde.TabStop = true;
            this.PlayerFedde.Text = "Fedde";
            this.PlayerFedde.UseVisualStyleBackColor = true;
            this.PlayerFedde.CheckedChanged += new System.EventHandler(this.PlayerFedde_CheckedChanged);
            // 
            // PlayerFer
            // 
            this.PlayerFer.AutoSize = true;
            this.PlayerFer.Location = new System.Drawing.Point(26, 74);
            this.PlayerFer.Name = "PlayerFer";
            this.PlayerFer.Size = new System.Drawing.Size(40, 17);
            this.PlayerFer.TabIndex = 4;
            this.PlayerFer.Text = "Fer";
            this.PlayerFer.UseVisualStyleBackColor = true;
            this.PlayerFer.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // PlayerSietse
            // 
            this.PlayerSietse.AutoSize = true;
            this.PlayerSietse.Location = new System.Drawing.Point(26, 51);
            this.PlayerSietse.Name = "PlayerSietse";
            this.PlayerSietse.Size = new System.Drawing.Size(54, 17);
            this.PlayerSietse.TabIndex = 3;
            this.PlayerSietse.Text = "Sietse";
            this.PlayerSietse.UseVisualStyleBackColor = true;
            this.PlayerSietse.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 117);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Wed Opties";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Wedders";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(244, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Wed Bureau";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.WedLblWorm1);
            this.panel2.Controls.Add(this.WedLblWorm4);
            this.panel2.Controls.Add(this.WedLblWorm3);
            this.panel2.Controls.Add(this.WedLblWorm2);
            this.panel2.Controls.Add(this.WedLblWorm5);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Location = new System.Drawing.Point(640, 81);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(562, 229);
            this.panel2.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(307, 23);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 26);
            this.label4.TabIndex = 11;
            this.label4.Text = "Plaats";
            // 
            // WedLblWorm1
            // 
            this.WedLblWorm1.AutoSize = true;
            this.WedLblWorm1.Location = new System.Drawing.Point(278, 78);
            this.WedLblWorm1.Name = "WedLblWorm1";
            this.WedLblWorm1.Size = new System.Drawing.Size(144, 13);
            this.WedLblWorm1.TabIndex = 10;
            this.WedLblWorm1.Text = "Race is nog niet begonnen...";
            // 
            // WedLblWorm4
            // 
            this.WedLblWorm4.AutoSize = true;
            this.WedLblWorm4.Location = new System.Drawing.Point(278, 145);
            this.WedLblWorm4.Name = "WedLblWorm4";
            this.WedLblWorm4.Size = new System.Drawing.Size(144, 13);
            this.WedLblWorm4.TabIndex = 9;
            this.WedLblWorm4.Text = "Race is nog niet begonnen...";
            // 
            // WedLblWorm3
            // 
            this.WedLblWorm3.AutoSize = true;
            this.WedLblWorm3.Location = new System.Drawing.Point(278, 123);
            this.WedLblWorm3.Name = "WedLblWorm3";
            this.WedLblWorm3.Size = new System.Drawing.Size(144, 13);
            this.WedLblWorm3.TabIndex = 8;
            this.WedLblWorm3.Text = "Race is nog niet begonnen...";
            // 
            // WedLblWorm2
            // 
            this.WedLblWorm2.AutoSize = true;
            this.WedLblWorm2.Location = new System.Drawing.Point(278, 100);
            this.WedLblWorm2.Name = "WedLblWorm2";
            this.WedLblWorm2.Size = new System.Drawing.Size(144, 13);
            this.WedLblWorm2.TabIndex = 7;
            this.WedLblWorm2.Text = "Race is nog niet begonnen...";
            // 
            // WedLblWorm5
            // 
            this.WedLblWorm5.AutoSize = true;
            this.WedLblWorm5.Location = new System.Drawing.Point(278, 167);
            this.WedLblWorm5.Name = "WedLblWorm5";
            this.WedLblWorm5.Size = new System.Drawing.Size(144, 13);
            this.WedLblWorm5.TabIndex = 6;
            this.WedLblWorm5.Text = "Race is nog niet begonnen...";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(30, 22);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(193, 13);
            this.label14.TabIndex = 5;
            this.label14.Text = "Sietse heeft geen weddeschap gedaan";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(30, 51);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(179, 13);
            this.label13.TabIndex = 4;
            this.label13.Text = "Fer heeft geen weddeschap gedaan";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(30, 78);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(194, 13);
            this.label12.TabIndex = 3;
            this.label12.Text = "Fedde heeft geen weddeschap gedaan";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(30, 123);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(156, 13);
            this.label11.TabIndex = 2;
            this.label11.Text = "Resultaten zijn nog niet bekend";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(30, 145);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(156, 13);
            this.label10.TabIndex = 1;
            this.label10.Text = "Resultaten zijn nog niet bekend";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(29, 167);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(156, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Resultaten zijn nog niet bekend";
            // 
            // Start_Button
            // 
            this.Start_Button.Location = new System.Drawing.Point(12, 261);
            this.Start_Button.Name = "Start_Button";
            this.Start_Button.Size = new System.Drawing.Size(562, 49);
            this.Start_Button.TabIndex = 2;
            this.Start_Button.Text = "Start De Race";
            this.Start_Button.UseVisualStyleBackColor = true;
            this.Start_Button.Click += new System.EventHandler(this.Start_Button_Click);
            // 
            // Worm
            // 
            this.Worm.BackColor = System.Drawing.Color.Transparent;
            this.Worm.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Worm.BackgroundImage")));
            this.Worm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Worm.ErrorImage = ((System.Drawing.Image)(resources.GetObject("Worm.ErrorImage")));
            this.Worm.Image = ((System.Drawing.Image)(resources.GetObject("Worm.Image")));
            this.Worm.InitialImage = ((System.Drawing.Image)(resources.GetObject("Worm.InitialImage")));
            this.Worm.Location = new System.Drawing.Point(1, 362);
            this.Worm.Name = "Worm";
            this.Worm.Size = new System.Drawing.Size(63, 55);
            this.Worm.TabIndex = 3;
            this.Worm.TabStop = false;
            this.Worm.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // WormTwo
            // 
            this.WormTwo.BackColor = System.Drawing.Color.Transparent;
            this.WormTwo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("WormTwo.BackgroundImage")));
            this.WormTwo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.WormTwo.Location = new System.Drawing.Point(1, 562);
            this.WormTwo.Name = "WormTwo";
            this.WormTwo.Size = new System.Drawing.Size(63, 55);
            this.WormTwo.TabIndex = 4;
            this.WormTwo.TabStop = false;
            // 
            // WormSpecial
            // 
            this.WormSpecial.BackColor = System.Drawing.Color.Transparent;
            this.WormSpecial.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("WormSpecial.BackgroundImage")));
            this.WormSpecial.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.WormSpecial.Location = new System.Drawing.Point(1, 493);
            this.WormSpecial.Name = "WormSpecial";
            this.WormSpecial.Size = new System.Drawing.Size(63, 55);
            this.WormSpecial.TabIndex = 5;
            this.WormSpecial.TabStop = false;
            // 
            // WormOne
            // 
            this.WormOne.BackColor = System.Drawing.Color.Transparent;
            this.WormOne.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("WormOne.BackgroundImage")));
            this.WormOne.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.WormOne.Location = new System.Drawing.Point(1, 423);
            this.WormOne.Name = "WormOne";
            this.WormOne.Size = new System.Drawing.Size(63, 55);
            this.WormOne.TabIndex = 6;
            this.WormOne.TabStop = false;
            // 
            // WormThree
            // 
            this.WormThree.BackColor = System.Drawing.Color.Transparent;
            this.WormThree.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("WormThree.BackgroundImage")));
            this.WormThree.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.WormThree.Location = new System.Drawing.Point(1, 627);
            this.WormThree.Name = "WormThree";
            this.WormThree.Size = new System.Drawing.Size(63, 55);
            this.WormThree.TabIndex = 7;
            this.WormThree.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1214, 683);
            this.Controls.Add(this.WormThree);
            this.Controls.Add(this.WormOne);
            this.Controls.Add(this.WormSpecial);
            this.Controls.Add(this.WormTwo);
            this.Controls.Add(this.Worm);
            this.Controls.Add(this.Start_Button);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "De Gokkers. ";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Choose_Worm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Inzet_Euro)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Worm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WormTwo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WormSpecial)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WormOne)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WormThree)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton PlayerFedde;
        private System.Windows.Forms.RadioButton PlayerFer;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label PlayerWedName;
        private System.Windows.Forms.Button Wed_Button;
        private System.Windows.Forms.NumericUpDown Choose_Worm;
        private System.Windows.Forms.NumericUpDown Inzet_Euro;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button Start_Button;
        private System.Windows.Forms.Label WedLblWorm1;
        private System.Windows.Forms.Label WedLblWorm4;
        private System.Windows.Forms.Label WedLblWorm3;
        private System.Windows.Forms.Label WedLblWorm2;
        private System.Windows.Forms.Label WedLblWorm5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox Worm;
        private System.Windows.Forms.PictureBox WormTwo;
        private System.Windows.Forms.PictureBox WormSpecial;
        private System.Windows.Forms.PictureBox WormOne;
        private System.Windows.Forms.PictureBox WormThree;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton PlayerSietse;
    }
}

